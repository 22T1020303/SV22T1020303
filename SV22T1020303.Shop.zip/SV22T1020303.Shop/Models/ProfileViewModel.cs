﻿using System.ComponentModel.DataAnnotations;

namespace SV22T1020303.Shop.Models.Account
{
    public class ProfileViewModel
    {
        public int CustomerID { get; set; }

        [Display(Name = "Tên khách hàng")]
        [Required(ErrorMessage = "Vui lòng nhập tên khách hàng.")]
        public string CustomerName { get; set; } = "";

        [Display(Name = "Tên liên hệ")]
        [Required(ErrorMessage = "Vui lòng nhập tên liên hệ.")]
        public string ContactName { get; set; } = "";

        [Display(Name = "Số điện thoại")]
        [Required(ErrorMessage = "Vui lòng nhập số điện thoại.")]
        public string Phone { get; set; } = "";

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Vui lòng nhập email.")]
        [EmailAddress(ErrorMessage = "Email không hợp lệ.")]
        public string Email { get; set; } = "";

        [Display(Name = "Tỉnh/Thành phố")]
        public string? Province { get; set; }

        [Display(Name = "Địa chỉ")]
        [Required(ErrorMessage = "Vui lòng nhập địa chỉ.")]
        public string Address { get; set; } = "";

        public bool IsLocked { get; set; }
    }
}