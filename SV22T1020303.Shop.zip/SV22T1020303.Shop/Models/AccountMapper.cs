﻿using LiteCommerce.Models.Partner;

namespace SV22T1020303.Shop.Models.Account
{
    public static class AccountMapper
    {
        public static Customer ToCustomer(this RegisterViewModel model)
        {
            return new Customer()
            {
                CustomerName = model.CustomerName,
                ContactName = model.ContactName,
                Phone = model.Phone,
                Email = model.Email,
                Province = model.Province,
                Address = model.Address,
                IsLocked = false
            };
        }

        public static ProfileViewModel ToProfileViewModel(this Customer customer)
        {
            return new ProfileViewModel()
            {
                CustomerID = customer.CustomerID,
                CustomerName = customer.CustomerName,
                ContactName = customer.ContactName,
                Phone = customer.Phone ?? "",
                Email = customer.Email,
                Province = customer.Province,
                Address = customer.Address ?? "",
                IsLocked = customer.IsLocked
            };
        }

        public static Customer ToCustomer(this ProfileViewModel model)
        {
            return new Customer()
            {
                CustomerID = model.CustomerID,
                CustomerName = model.CustomerName,
                ContactName = model.ContactName,
                Phone = model.Phone,
                Email = model.Email,
                Province = model.Province,
                Address = model.Address,
                IsLocked = model.IsLocked
            };
        }
    }
}