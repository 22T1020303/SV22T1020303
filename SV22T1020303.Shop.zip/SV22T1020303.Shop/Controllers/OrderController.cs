﻿using LiteCommerce.BusinessLayers;
using LiteCommerce.Models.Sales;
using LiteCommerce.Shop;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SV22T1020303.BusinessLayers;

namespace SV22T1020303.Shop.Controllers
{
    [Authorize]
    public class OrderController : Controller
    {
        [HttpGet]
        public async Task<IActionResult> Checkout()
        {
            var cart = ShoppingCartService.GetShoppingCart();
            if (cart.Count == 0)
            {
                TempData["ErrorMessage"] = "Giỏ hàng đang trống.";
                return RedirectToAction("Index", "Cart");
            }

            ViewBag.Provinces = await SelectListHelper.ProvincesAsync();

            var userData = User.GetUserData();
            if (userData != null && !string.IsNullOrEmpty(userData.UserId))
            {
                int customerID = int.Parse(userData.UserId);
                var customer = await PartnerDataService.GetCustomerAsync(customerID);
                ViewBag.Customer = customer;
            }

            return View(cart);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Checkout(string deliveryProvince, string deliveryAddress, string deliveryPhone)
        {
            try
            {
                var cart = ShoppingCartService.GetShoppingCart();
                if (cart.Count == 0)
                {
                    TempData["ErrorMessage"] = "Giỏ hàng đang trống.";
                    return RedirectToAction("Index", "Cart");
                }

                if (string.IsNullOrWhiteSpace(deliveryProvince))
                    ModelState.AddModelError("deliveryProvince", "Vui lòng chọn tỉnh/thành phố.");

                if (string.IsNullOrWhiteSpace(deliveryAddress))
                    ModelState.AddModelError("deliveryAddress", "Vui lòng nhập địa chỉ giao hàng.");

                if (string.IsNullOrWhiteSpace(deliveryPhone))
                    ModelState.AddModelError("deliveryPhone", "Vui lòng nhập số điện thoại nhận hàng.");

                var userData = User.GetUserData();
                if (userData == null || string.IsNullOrEmpty(userData.UserId))
                    return RedirectToAction("Login", "Account");

                int customerID = int.Parse(userData.UserId);

                if (!ModelState.IsValid)
                {
                    ViewBag.Provinces = await SelectListHelper.ProvincesAsync();
                    ViewBag.Customer = await PartnerDataService.GetCustomerAsync(customerID);
                    return View(cart);
                }

                var newOrder = new Order()
                {
                    CustomerID = customerID,
                    DeliveryProvince = deliveryProvince,
                    DeliveryAddress = deliveryAddress,
                    Status = OrderStatusEnum.New
                };

                int orderID = await SalesDataService.AddOrderAsync(newOrder);

                foreach (var item in cart)
                {
                    await SalesDataService.AddDetailAsync(new OrderDetail()
                    {
                        OrderID = orderID,
                        ProductID = item.ProductID,
                        Quantity = item.Quantity,
                        SalePrice = item.SalePrice
                    });
                }

                ShoppingCartService.ClearCart();
                TempData["SuccessMessage"] = "Đặt hàng thành công. Đơn hàng đang chờ duyệt.";

                return RedirectToAction("Details", new { id = orderID });
            }
            catch
            {
                TempData["ErrorMessage"] = "Không thể đặt hàng lúc này.";
                return RedirectToAction("Index", "Cart");
            }
        }

        public async Task<IActionResult> History(int page = 1)
        {
            var userData = User.GetUserData();
            if (userData == null || string.IsNullOrEmpty(userData.UserId))
                return RedirectToAction("Login", "Account");

            int customerID = int.Parse(userData.UserId);

            var input = new OrderSearchInput()
            {
                Page = 1,
                PageSize = 1000,
                SearchValue = ""
            };

            var result = await SalesDataService.ListOrdersAsync(input);
            var myOrders = result.DataItems
                                 .Where(x => x.CustomerID == customerID)
                                 .OrderByDescending(x => x.OrderTime)
                                 .ToList();

            return View(myOrders);
        }

        public async Task<IActionResult> Details(int id)
        {
            var userData = User.GetUserData();
            if (userData == null || string.IsNullOrEmpty(userData.UserId))
                return RedirectToAction("Login", "Account");

            int customerID = int.Parse(userData.UserId);

            var order = await SalesDataService.GetOrderAsync(id);
            if (order == null || order.CustomerID != customerID)
            {
                TempData["ErrorMessage"] = "Không tìm thấy đơn hàng hoặc bạn không có quyền xem đơn này.";
                return RedirectToAction("History");
            }

            var details = await SalesDataService.ListDetailsAsync(id);
            ViewBag.OrderDetails = details;

            return View(order);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Cancel(int id)
        {
            try
            {
                var userData = User.GetUserData();
                if (userData == null || string.IsNullOrEmpty(userData.UserId))
                    return RedirectToAction("Login", "Account");

                int customerID = int.Parse(userData.UserId);

                var order = await SalesDataService.GetOrderAsync(id);
                if (order == null || order.CustomerID != customerID)
                {
                    TempData["ErrorMessage"] = "Không tìm thấy đơn hàng.";
                    return RedirectToAction("History");
                }

                if (order.Status != OrderStatusEnum.New)
                {
                    TempData["ErrorMessage"] = "Chỉ được hủy đơn hàng đang chờ duyệt.";
                    return RedirectToAction("Details", new { id });
                }

                order.Status = OrderStatusEnum.Cancelled;
                await SalesDataService.UpdateOrderAsync(order);

                TempData["SuccessMessage"] = "Đã hủy đơn hàng thành công.";
                return RedirectToAction("History");
            }
            catch
            {
                TempData["ErrorMessage"] = "Không thể hủy đơn hàng lúc này.";
                return RedirectToAction("History");
            }
        }
    }
}