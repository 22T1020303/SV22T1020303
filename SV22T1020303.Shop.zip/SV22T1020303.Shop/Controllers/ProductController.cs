﻿using LiteCommerce.BusinessLayers;
using SV22T1020303.BusinessLayers;
using LiteCommerce.Models.Catalog;
using LiteCommerce.Models.Common;
using LiteCommerce.Models.Partner;
using Microsoft.AspNetCore.Mvc;
using SV22T1020303.Shop;

namespace SV22T1020303.Shop.Controllers
{
    public class ProductController : Controller
    {
        private const string SEARCH_CONDITION = "ProductSearchCondition";

        public async Task<IActionResult> Index()
        {
            ViewBag.Title = "Quản lý mặt hàng";

            var input = ApplicationContext.GetSessionData<ProductSearchInput>(SEARCH_CONDITION);
            if (input == null)
            {
                input = new ProductSearchInput()
                {
                    Page = 1,
                    PageSize = ApplicationContext.PageSize,
                    SearchValue = "",
                    CategoryID = 0,
                    SupplierID = 0,
                    MinPrice = 0,
                    MaxPrice = 0
                };
            }

            ApplicationContext.SetSessionData(SEARCH_CONDITION, input);

            await PrepareViewBagsAsync();

            var data = await SearchDataAsync(input);
            ViewBag.SearchInput = input;

            return View(data);
        }

        [HttpGet]
        public async Task<IActionResult> Search(ProductSearchInput input)
        {
            ViewBag.Title = "Tra cứu mặt hàng";

            NormalizeSearchInput(input);

            if (input.Page <= 0)
                input.Page = 1;

            if (input.PageSize <= 0)
                input.PageSize = ApplicationContext.PageSize;

            if (input.MinPrice < 0)
                ModelState.AddModelError(nameof(input.MinPrice), "Giá tối thiểu không được âm.");

            if (input.MaxPrice < 0)
                ModelState.AddModelError(nameof(input.MaxPrice), "Giá tối đa không được âm.");

            if (input.MaxPrice > 0 && input.MinPrice > input.MaxPrice)
                ModelState.AddModelError(nameof(input.MaxPrice), "Giá tối đa phải lớn hơn hoặc bằng giá tối thiểu.");

            await PrepareViewBagsAsync();
            ViewBag.SearchInput = input;

            if (!ModelState.IsValid)
            {
                var emptyData = new PagedResult<Product>()
                {
                    Page = input.Page,
                    PageSize = input.PageSize,
                    RowCount = 0,
                    DataItems = new List<Product>()
                };

                if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                    return PartialView(emptyData);

                return View("Index", emptyData);
            }

            ApplicationContext.SetSessionData(SEARCH_CONDITION, input);
            var data = await SearchDataAsync(input);

            if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                return PartialView(data);

            return View("Index", data);
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id = 0)
        {
            ViewBag.Title = "Chi tiết mặt hàng";

            if (id <= 0)
                return RedirectToAction("Index");

            await PrepareViewBagsAsync();

            var data = await CatalogDataService.GetProductAsync(id);
            if (data == null)
                return RedirectToAction("Index");

            return View(data);
        }

        private void NormalizeSearchInput(ProductSearchInput input)
        {
            if (string.IsNullOrWhiteSpace(Request.Query["SearchValue"]))
                input.SearchValue = "";

            if (string.IsNullOrWhiteSpace(Request.Query["CategoryID"]))
            {
                input.CategoryID = 0;
                ModelState.Remove(nameof(input.CategoryID));
            }

            if (string.IsNullOrWhiteSpace(Request.Query["SupplierID"]))
            {
                input.SupplierID = 0;
                ModelState.Remove(nameof(input.SupplierID));
            }

            if (string.IsNullOrWhiteSpace(Request.Query["MinPrice"]))
            {
                input.MinPrice = 0;
                ModelState.Remove(nameof(input.MinPrice));
            }

            if (string.IsNullOrWhiteSpace(Request.Query["MaxPrice"]))
            {
                input.MaxPrice = 0;
                ModelState.Remove(nameof(input.MaxPrice));
            }

            if (string.IsNullOrWhiteSpace(Request.Query["Page"]))
            {
                input.Page = 1;
                ModelState.Remove(nameof(input.Page));
            }

            if (string.IsNullOrWhiteSpace(Request.Query["PageSize"]))
            {
                input.PageSize = ApplicationContext.PageSize;
                ModelState.Remove(nameof(input.PageSize));
            }
        }

        private async Task PrepareViewBagsAsync()
        {
            var categoryInput = new PaginationSearchInput()
            {
                Page = 1,
                PageSize = 1000,
                SearchValue = ""
            };

            var supplierInput = new PaginationSearchInput()
            {
                Page = 1,
                PageSize = 1000,
                SearchValue = ""
            };

            var categories = await CatalogDataService.ListCategoriesAsync(categoryInput);
            var suppliers = await PartnerDataService.ListSuppliersAsync(supplierInput);

            ViewBag.Categories = categories.DataItems;
            ViewBag.Suppliers = suppliers.DataItems;
            ViewBag.CategoryNames = categories.DataItems.ToDictionary(x => x.CategoryID, x => x.CategoryName);
            ViewBag.SupplierNames = suppliers.DataItems.ToDictionary(x => x.SupplierID, x => x.SupplierName);
        }

        private async Task<PagedResult<Product>> SearchDataAsync(ProductSearchInput input)
        {
            var allDataInput = new ProductSearchInput()
            {
                Page = 1,
                PageSize = 1000,
                SearchValue = input.SearchValue ?? "",
                CategoryID = 0,
                SupplierID = 0,
                MinPrice = 0,
                MaxPrice = 0
            };

            var sourceData = await CatalogDataService.ListProductsAsync(allDataInput);
            IEnumerable<Product> query = sourceData.DataItems;

            if (input.CategoryID > 0)
                query = query.Where(x => x.CategoryID == input.CategoryID);

            if (input.SupplierID > 0)
                query = query.Where(x => x.SupplierID == input.SupplierID);

            if (input.MinPrice > 0)
                query = query.Where(x => x.Price >= input.MinPrice);

            if (input.MaxPrice > 0)
                query = query.Where(x => x.Price <= input.MaxPrice);

            var filteredData = query.ToList();
            int rowCount = filteredData.Count;

            var pageData = filteredData
                .Skip((input.Page - 1) * input.PageSize)
                .Take(input.PageSize)
                .ToList();

            return new PagedResult<Product>()
            {
                Page = input.Page,
                PageSize = input.PageSize,
                RowCount = rowCount,
                DataItems = pageData
            };
        }
    }
}