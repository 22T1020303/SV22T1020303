﻿using LiteCommerce.BusinessLayers;
using LiteCommerce.Models.Sales;
using LiteCommerce.Shop;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace SV22T1020303.Shop.Controllers
{
    [Authorize]
    public class CartController : Controller
    {
        public IActionResult Index()
        {
            var cart = ShoppingCartService.GetShoppingCart();
            return View(cart);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddToCart(int productId, int quantity = 1)
        {
            var product = await CatalogDataService.GetProductAsync(productId);
            if (product == null)
            {
                TempData["ErrorMessage"] = "Sản phẩm không tồn tại.";
                return RedirectToAction("Index", "Product");
            }

            var item = new OrderDetailViewInfo()
            {
                ProductID = product.ProductID,
                ProductName = product.ProductName,
                Unit = product.Unit,
                Quantity = quantity <= 0 ? 1 : quantity,
                SalePrice = product.Price,
                Photo = product.Photo
            };

            ShoppingCartService.AddCartItem(item);
            TempData["SuccessMessage"] = "Đã thêm sản phẩm vào giỏ hàng.";

            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Update(int productId, int quantity)
        {
            var item = ShoppingCartService.GetCartItem(productId);
            if (item != null)
            {
                if (quantity <= 0)
                    ShoppingCartService.RemoveCartItem(productId);
                else
                    ShoppingCartService.UpdateCartItem(productId, quantity, item.SalePrice);
            }

            TempData["SuccessMessage"] = "Cập nhật giỏ hàng thành công.";
            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Remove(int productId)
        {
            ShoppingCartService.RemoveCartItem(productId);
            TempData["SuccessMessage"] = "Đã xóa sản phẩm khỏi giỏ hàng.";
            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Clear()
        {
            ShoppingCartService.ClearCart();
            TempData["SuccessMessage"] = "Đã xóa toàn bộ giỏ hàng.";
            return RedirectToAction("Index");
        }
    }
}